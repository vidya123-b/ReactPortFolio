export default function Profile() {
  return (
    <div className="content">
      <h1>Profile</h1>
      <h1>Full Stack JavaDevloper</h1>
    </div>
  );
}
