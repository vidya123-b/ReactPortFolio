import { FaTwitter, FaLinkedin } from "react-icons/fa6";
import { MdEmail } from "react-icons/md";

export default function Contact() {
  return (
    <div className="content contact">
      <div>
        <h1>Contact</h1>
      </div>
      <div className="contactContainer">
        <div className="connectionLinks">
          <h3>
            <MdEmail className="connectionIcon" />
          </h3>
          <a href="mailto:bhagatvidya23@gmail.com" target="_blank">
            bhagatvidya23@gmail.com
          </a>
        </div>
        <div className="connectionLinks">
          <h3>
            <FaLinkedin className="connectionIcon" />
          </h3>
          <a href="https://www.linkedin.com/in/vidya-bhagat/" target="_blank">
          Vidya Bhagat
          </a>
        </div>

        <div className="connectionLinks">
          <h3>
            <FaTwitter className="connectionIcon" />
          </h3>
          <a href="https://github.com/vidya123-b">GitHub</a>
        </div>
      </div>
    </div>
  );
}
