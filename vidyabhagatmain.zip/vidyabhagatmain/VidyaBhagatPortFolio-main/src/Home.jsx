import { IoMdHand } from "react-icons/io";
import { FaTwitter, FaGithub, FaLinkedin } from "react-icons/fa6";

import Pic from "/src/assets/profile3.png";
export default function Home() {
  return (
    <div className="content home">
      <div>
        <img className="profilePic" src={Pic} alt="Profile" />
      </div>
      <div className="intro">
        <h1>
          Hello,
          <span className="hello">
            <IoMdHand className="hello" />
          </span>
        </h1>
        <h1>
          My Name is <span className="name"> Vidya Bhagat</span>
        </h1>
        <h2>I am a Full Stack Java Devloper</h2>
        <div className="connection ">
          <a href="www.linkedin.com/in/vidya-bhagat" target="_blank">
            <FaLinkedin className="icon" />
          </a>{" "}
          <a href="https://github.com/vidya123-b" target="_blank">
            <FaGithub className="icon" />
          </a>
        </div>
      </div>
    </div>
  );
}
